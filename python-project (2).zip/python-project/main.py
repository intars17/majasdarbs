n = int(input("Ievadi veselu skaitli n: "))
suma = sum(range(1, n + 1))
print(f"Skaitļu summa no 1 līdz {n} ir: {suma}")
