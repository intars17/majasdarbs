a = int(input("Ievadi pirmo skaitli: "))
s = int(input("Ievadi otro skaitli: "))
d = int(input("Ievadi trešo skaitli: "))

lielakais = max(a, s, d)

print(f"Lielākais no ievadītajiem skaitļiem ir: {lielakais}")
