atzimes = [7, 8, 4, 9, 10, 6, 8]
skaits = len(atzimes)
videjais = sum(atzimes) / skaits
lielakais = max(atzimes)
septini_vai_lielaki = 0
for atzime in atzimes:
  if atzime >= 7:
    septini_vai_lielaki = septini_vai_lielaki + 1
print("Atzīmju skaits:", skaits)
print("Vidējā atzīme:", videjais)
print("Lielākā atzīme:", lielakais)
print("Atzīmju skaits kas ir 7 vai lielākas:", septini_vai_lielaki)
